package com.example.bindableadaptertest;

import java.util.ArrayList;

public class Category {
    public String title;
    public ArrayList<Product> products;
}
