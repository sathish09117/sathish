package com.example.bindableadaptertest;


public class Product {

    public String title;
    public String description;
    public String imageUrl;
    public double price;
}
