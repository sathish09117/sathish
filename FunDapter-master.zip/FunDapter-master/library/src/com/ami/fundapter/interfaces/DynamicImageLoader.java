package com.ami.fundapter.interfaces;


import android.widget.ImageView;

public interface DynamicImageLoader {
    public void loadImage(String url, ImageView view);
}
